duvida no ex 06 de 07
