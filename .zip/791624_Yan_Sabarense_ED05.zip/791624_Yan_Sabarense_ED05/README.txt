duvida:
exemplo 0517 (nao soube se fiz corretamente)
exemplo 0519 (nao consegui fazer)
exemplo 0520 (nao sei se esta correto)