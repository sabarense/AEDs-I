rever exemplo 0404 e exemplo 0406, não entendi a parte do " separadas por uma função"

exemplo 0419, o resultado é : Nova palavra = [þc╚v☺A1b2C3d4E5f6]
não consegui inicializar e definir um valor para cadeia de caracteres, entao creio que seja por isso que a primeira parte("þc╚v☺") retorna lixo.