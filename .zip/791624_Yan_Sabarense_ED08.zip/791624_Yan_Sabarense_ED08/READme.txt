rever exemplo 813 e 814, 
nao soube fazer a partir do exemplo 0817, onde tem que dizer se o arranjo esta ordenado