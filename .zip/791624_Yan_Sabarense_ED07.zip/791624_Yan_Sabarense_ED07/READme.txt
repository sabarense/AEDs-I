duvida no exemplo 0712, nao sei se fiz corretamente

duvida no exemplo 0713, nao sei se fiz corretamente

duvida no exemplo 0714, nao consegui imprimir decrescentemente

nao consegui fiquei com duvida do 0716 em diante